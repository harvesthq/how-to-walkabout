$(function(){
  if($("#walkabout_mapspot").length){
    $("#footer").hide();
    map_resize();
    $(window).resize( map_resize );
    initialize();
    set_up_map();
  }  
}); 

function set_up_map(){
  var companies = $("li.wa-com");
  
  for(var i=companies.length-1; i>-1; i--){
    var com = $(companies[i]);
    createMapMarker(com.attr("id"), com.find("input.wacom-latlong").val());
    com.css("cursor","pointer");
    com.click(directory_click);
  }
  map.fitBounds(bounds)
  map.setCenter(bounds.getCenter());
}

function directory_click(e){
  e.preventDefault();
  map_show( $(this).attr("id") );
}

function map_show(id){
   if(currentMapMarker){
     $("li#"+currentMapMarker).removeClass("highlight");
     companies[currentMapMarker].infoWin.close();
   }
   currentMapMarker = id;
   companies[id].infoWin.open(map, companies[id].marker);
   $("li#"+currentMapMarker).addClass("highlight");
   map.setCenter(companies[id].marker.getPosition());
}

function get_content_string(item){

  var content = '<div class="map-infowin">'+item.html()+'</div>';
  return content

}

var currentMapMarker = null;
var companies = new Array();

function createMapMarker(id , latlngstring){
  companies[id] = {};
  
  var coords = latlngstring.split(",");
  
  var latlng = new google.maps.LatLng(coords[0], coords[1]);
  companies[id].marker = new google.maps.Marker({ position: latlng, map: map, title: id });
  
  bounds.extend(latlng);
  
  contentString = get_content_string($("#"+id));
  companies[id].infoWin = new google.maps.InfoWindow({ content: contentString });
  
  google.maps.event.addListener(companies[id].marker, 'click', function() { map_show(this.title); });
}

var map;
var bounds;

function initialize() {
  
  
  var harvest = new google.maps.LatLng(40.720786, -73.998427);
  bounds = new google.maps.LatLngBounds(0,0);

  var railStyle = [ {
            featureType: "transit.line",
            elementType: "geometry",
            stylers: [{visibility: "off"}]
          },{
            featureType: "transit.line",
            elementType: "labels",
            stylers: [{
              saturation: -100
            },{
              lightness: 33
            }]
          },{
      featureType: "administrative",
      stylers: [{ visibility: "off" }]
    },{
      featureType: "administrative.country",
      stylers: [{ visibility: "on"  }]
    },{
      featureType: "administrative.land_parcel",
      stylers: [{ visibility: "on"  }]
    },{
      featureType: "administrative.locality",
      stylers: [{ visibility: "on"  }]
    },{
      featureType: "administrative.neighborhood",
      stylers: [{ visibility: "on"  }]
    },{
      featureType: "administrative.province",
      stylers: [{ visibility: "on"  },
                { lightness:  50    }]
    },{
      featureType: "landscape",
      stylers: [{
        saturation: -100 
      },{
        lightness: 75
      }]
    },{
      featureType: "poi",
      stylers: [{ visibility: "off" }]
    },{
      featureType: "poi.attraction",
      stylers: [{ visibility: "on"  }]
    },{
      featureType: "poi.business",
      stylers: [{ visibility: "on"  }]
    },{
      featureType: "poi.government",
      stylers: [{ visibility: "on"  }]
    },{
      featureType: "poi.medical",
      stylers: [{ visibility: "on"  }]
    },{
      featureType: "poi.place_of_worship",
      stylers: [{ visibility: "on"  }]
    },{
      featureType: "poi.school",
      stylers: [{ visibility: "on"  }]
    },{
      featureType: "poi.sports_complex",
      stylers: [{ visibility: "on"  }]
    },{
      featureType: "poi",
      stylers: [{
        saturation: -100
      },{
        lightness: 20
      }]
    },{
      featureType: "road",
      stylers: [{
        saturation: -100
      },{
        lightness: 50
      }]
    },{
      featureType: "water",
      stylers: [{
        lightness: 75
      },{
        saturation: 50
      }]
    }];

  var mapOptions = {
    zoom: 14,
    center: harvest
  };
  map = new google.maps.Map(document.getElementById("walkabout_map"), mapOptions);

  var railMapType = new google.maps.StyledMapType(railStyle, {
    name: "Walkabout"
  });

  map.mapTypes.set('rail', railMapType);
  map.setMapTypeId('rail');

  map.setOptions({
    mapTypeControlOptions: {
      mapTypeIds: [
        'rail',
        google.maps.MapTypeId.ROADMAP,
        google.maps.MapTypeId.TERRAIN,
        google.maps.MapTypeId.SATELLITE,
        google.maps.MapTypeId.HYBRID
      ]
    }
  });

  var railLayer = new google.maps.KmlLayer('United-States-New-York.kml',{
    map: map,
    suppressInfoWindows: true,
    preserveViewport: true
  });
  
}        

function map_resize(){
  var wh = $(window).height();
  var ww = $(window).width();

  if(wh > 636) $("#walkabout_mapspot").height( wh - 136 );
  else $("#walkabout_mapspot").height( 500 );
  
  if(ww > 960){
    $("#container").width( ww );
    $("#walkabout_map").width( ww - $("#walkabout_directory").width() );
  }
  else{
    $("#container").width( 960 );
    $("#walkabout_map").width( 960 - $("#walkabout_directory").width() );
  }
  
  if(map) google.maps.event.trigger(map, 'resize');

}


/*
    END MAP STUFF
*/







$(function(){
  if($("#kykklh-kykklh").length) do_cam_mon_setup();
  
});
$.backstretch("/nyc_background_50.jpg");

function do_cam_mon_setup(){
  $("#kykklh-kykklh").focus(function(){ $("#kykklh-kykklh-label").hide(); });
  $("#subForm input:submit").click(function(){
    $('form#subForm').submit(function() { return false; });
    var formAction = $("form#subForm").attr("action");
    var id = "kykklh";
    var emailId = id + "-" + id;
    if (!checkEmail(emailId)){
			alert("Please enter a valid email address");
			return;
		}
		var str = $("form#subForm").serialize();
		var serialized = str + "&action=" + formAction;
		$.ajax({
			url: "proxy.php", type: "POST", data: serialized,
			success: function(data){
			  if (data.search(/invalid/i) != -1){
					alert('The email address you supplied is invalid and needs to be fixed before you can subscribe to this list.');
				}
  			else{
  				$("#kykklh-kykklh").blur().val("");
  				$("#kykklh-kykklh-label").text("Success. We'll see you there!").show();
  			}
  		}
  	});
  }); 
}

function checkEmail(email){	
	var pattern = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var emailVal = $("#" + email).val();
	return pattern.test(emailVal);
}