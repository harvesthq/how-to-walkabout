<style>h2 { font-weight:bold; font-size:1.15em;}</style>
<div class="content">
 <div class="con-bg"></div>
 <div class="content-container" id="faq">
  <h1 id="faq-head" class="headline">FAQ</h1>
  <h2>What is Walkabout NYC?</h2>
  <p>Walkabout NYC is a celebration of the technology and entrepreneurial culture in New York City. On Friday, June 10th, startups behind your favorite products will host a city-wide open house. You will be able to stop by and check out their workspaces, see how they work, and meet the people leading the technology charge in New York City.</p>

  <h2>When is Walkabout NYC?</h2>
  <p>Walkabout NYC is Friday, June 10, 2010, from 12pm - 6pm.</p>

  <h2>Are we associated with Internet Week?</h2>
  <p>Walkabout NYC is an <a href="https://www.internetweekny.com/schedule?event=590" target="new">official Internet Week NY event</a>.</p>

  <h2>Where do I go?</h2>
  <p>There is a <a href="/map/">map on this very website</a>, with all of the company information for each participant.  There is also a mobile-friendly web view of the directory and map, so iPhone/Android/other smartphone users can access all of the event information while you're on the go.</p>
	
	<h2>Is this a structured tour?</h2>
  <p>There is no structured tour - you are free to set your own route, and visit the companies of your choosing. Check the information for each company, as they may have slightly different open hours, and timed events that you don't want to miss.</p>
  
  <h2>How do I meet others who will also be on Walkabout NYC?</h2>
  <p>If you were planning on walking solo, stop by Harvest HQ first and meet a fellow walker. We'll send you off with others who'd prefer to meet a new friend at the top of each hour.</p>
  
  <h2>What if I only have my lunch hour to Walkabout NYC? What if I only have 2 or 3 hours - where should I go?</h2>
  <p>Find the neighborhood closest to where you work, and start exploring!</p>
  
  <h2>Is this free to attend?</h2>
  <p>Yes, it's really free. Walkabout NYC costs you zero dollars.</p>
  
  <h2>Do you have a hashtag?</h2>
  <p>Why yes we do: #walkaboutnyc</p>
  
  <h2>I have a question. How do I get in touch with you? </h2>
  <p>Write us from our <a href="/contact/">contact page</a>.</p>
  
  <p>Now get out there and go explore!</p>
  
 </div>
</div>