<div class="content-dark">
  <div class="con-bg"></div>
  <div class="home">
    <h2>A behind-the-scenes look at the workspaces of New York technology companies.</h2>
    <p>
			Walkabout NYC is a celebration of the technology and entrepreneurial culture in New York City.  On Friday, June 10th,  startups behind your favorite products and services will host a city-wide open house.  Check out the workspaces, see how they work, and meet the people leading the technology charge in New York City.<br />
		</p>
    <form action="http://iridesco.createsend.com/t/r/s/kykklh/" method="post" id="subForm">
      <div class="form-field">
        <label for="kykklh-kykklh" id="kykklh-kykklh-label">Enter your Email Address</label>
        <input type="text" name="cm-kykklh-kykklh" id="kykklh-kykklh" />
      </div>
      <input type="submit" value="Submit" />
      <p class="email-reminder">Leave us your email and we'll keep you in the loop!</p>
      <br/>
      <p class="videotour"><a href="http://vimeo.com/groups/walkaboutnyc/videos/sort:oldest" target="new"><img src="harvest_vimeo.png" class="videoimg">Preview some videos</a> of office tours you can take on June 10th</p>
    </form>
  </div>
  <div class="clear"></div>
</div>