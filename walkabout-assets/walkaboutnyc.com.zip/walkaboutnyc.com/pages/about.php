<style>h2 { font-weight:bold; font-size:1.15em;}</style>
<div class="content">
 <div class="con-bg"></div>
 <div class="content-container" id="about">
  <h1 id="about-head" class="headline">About Walkabout NYC</h1>
  <p>Walkabout NYC is a city-wide open house event for technology startups. Check out the spaces, see how the companies work, and meet the people behind the innovative companies of New York City.</p>

  <h2>Who is invited?</h2>
  <p>Everyone. Stop by any participating company during their designated hours for a behind-the-scenes look at their space. For Walkabout NYC, most companies are available during 12pm - 6pm but please <a href="/map/">check the directory/map</a> to ensure you are showing up during the designated Walkabout hours for each company.</p>

  <h2>Why participate in Walkabout NYC as a company?</h2>
  <p>It&rsquo;s an opportunity to meet new people who would find your company&rsquo;s story, culture, and product interesting. It&rsquo;s a way to get talented individuals interested in working at your company and in New York City. It&rsquo;s a chance to meet the neighbors. And it can be as simple as having someone greet your visitors and walking them through your space.</p>

  <h2>The Back Story</h2>
  <p>Danny Wen and Shawn Liu, the founders of Harvest, have always enjoyed taking tours of creative and entrepreneurial workspaces. No matter what size, they found the spaces always fostered inspirational energy. From forming the company in a tiny shared office to Harvest&rsquo;s current home in a Soho loft, Danny and Shawn recognize how instrumental those behind-the-scenes experiences were along the way.</p>

  <p>Today, Harvest HQ has become a gathering point where the founders invite others to visit their workspace and share their tools of the trade. Alongside their friends and colleagues creating innovative products in their cool studios and offices, it&rsquo;s time to bring the community together for a citywide &ldquo;open house&rdquo; of technology companies. The goal is simple: to put New York City&rsquo;s vibrant tech scene on the map and to inspire each other and the growing generation of entrepreneurs.</p>
 </div>
</div>