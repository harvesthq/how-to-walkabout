<?
  ini_set('display_errors', 0);
  include("../company.php");
?>
<!doctype html>
<html>
    <head>
        <meta charset="UTF-8" />
        <title>Walkabout NYC</title>
        <style type="text/css" media="screen">@import "jqtouch/jqtouch.css";</style>
        <style type="text/css" media="screen">@import "themes/harvest/theme.css";</style>
        <script src="jqtouch/jquery-1.4.2.js" type="text/javascript" charset="utf-8"></script>
        <script src="jqtouch/jqtouch.js" type="application/x-javascript" charset="utf-8"></script>
        <script type="text/javascript" charset="utf-8">
            var jQT = new $.jQTouch({
                icon: 'apple-touch-icon.png',
                statusBar: 'black'
            });
        </script>
    </head>
	<body> 
	  <div id="jqt">
      <div id="home">
        <div class="toolbar header">
          <h1>Walkabout NYC</h1>
        </div>
        <div class="sep">
          <div class="bgdiv"></div>
          <p><b>June 10th, 2011</b></p>
        </div>
          <div class="home-content">
            <div class="bgdiv"></div>
            <p>Walkabout is a behind-the-scenes look at the workspaces of New York technology companies.</p>
          </div>
          <ul class="harvest">
              <li class="arrow"><div class="bgdiv"></div><a href="#about-walkabout">About Walkabout NYC</a></li>
              <li class="arrow"><div class="bgdiv"></div><a href="#companies">Participating Companies</a></li>
          </ul>
          <div class="info">
              <p>Add this page to your home screen and use it as your guide to Walkabout NYC.</p>
          </div>
          <div class="">
            <a href="#presented-by" class="presented-link">Presented By Harvest</a>
          </div>
      </div>
      <div id="about-walkabout">
        <div class="toolbar header">
          <h1>Walkabout NYC</h1>
          <a class="back" href="#">Back</a>        
        </div>
        <div class="content">
          <div class="bgdiv"></div>
          <h2>About Walkabout NYC</h2>
          <div class="content-block">
            <p>
              <strong>What Is Walkabout NYC?</strong><br />
              It&rsquo;s a city-wide open house event for technology startups. Check out the spaces, see how the companies work, and meet the people behind the innovative companies of New York City.            
            </p>
          </div>
          <div class="content-block">
            <p>
              <b>Who is invited?</b><br />
              Everyone. Stop by any participating company during their designated hours for a behind-the-scenes look at their space. For Walkabout NYC, most companies are available during 12pm - 7pm but please check the company list to ensure you are showing up during the designated Walkabout hours for each company.
            </p>
          </div>
        </div>
      </div>
      <div id="presented-by">
        <div class="toolbar header">
          <h1>Walkabout NYC</h1>
          <a class="back" href="#">Back</a>        
        </div>
        <div class="content">
          <div class="bgdiv"></div>
          <h2>Presented By Harvest</h2>
          <div class="content-block">
            <p>
              Walkabout NYC is spearheaded by Harvest, an online time tracking and invoicing service. Based in the heart of Soho, we are passionate about making it easier for teams around the world to track billable time. Learn more about what we do at <a href="http://getharvest.com/" target="_blank">getHarvest.com</a>.
            </p>
          </div>
        </div>
      </div>
  <?
     $company_list = array();

    foreach($companies AS $company):
      if(!array_key_exists($company->neighborhood, $company_list)) $company_list[$company->neighborhood] = array();
      $addy = split(",",$company->address);
    
      $c_name = ($company->name=="Harvest") ? "Harvest / Walkabout HQ" : $company->name;
      $company_list[$company->neighborhood][] = array("slug"=>$company->slug, "address"=>$addy[0], "name"=>$c_name);
  ?>
    <div id="<?= $company->slug ?>">
      <div class="toolbar header">
        <h1>Walkabout NYC</h1>
        <a class="back" href="#<?= preg_replace(array("/ /", "/\//"), "", $company->neighborhood) ?>">Back</a>        
      </div>
      <div class="content">
        <div class="bgdiv"></div>
        <h2><?= $c_name ?></h2>
        <div class="content-block">
          <div style="width:100%; text-align:center; margin-bottom:1em;">
          <img src="http://maps.google.com/maps/api/staticmap?center=<?= $addy[0] ?>+<?= ($company->neighborhood=="Brooklyn") ? "Brooklyn, New York" : "New York City"; ?>&amp;zoom=16&amp;size=280x250&amp;maptype=roadmap&amp;markers=<?= $company->latlong ?>&amp;sensor=false" style="position:relative; margin:0 auto;" onClick="window.location='http://maps.google.com/maps?q=<?= $addy[0] ?>, <?= ($company->neighborhood=="Brooklyn") ? "Brooklyn, New York" : "New York City"; ?>';" />
        </div>
          <p>
            <?= $company->address ?><br />
            <em><?= $company->neighborhood ?><br /></em>
          </p>
          <p style="margin-top:10px;">
            <strong>Hours:</strong> <?= $company->hours ?><br />
          </p>
        </div>
        <div class="content-block">
          <p>
            <?= $company->description ?>
          </p>
          <? if(isset($company->details)): ?><p><em><?= $company->details ?></em></p><? endif; ?>
          <p>
            <a href="<?= $company->url ?>" target="_blank"><?= $company->short_url() ?></a>
          </p>
        </div>
      </div>
    </div>
  <?
    endforeach;
  ?>
  <?php
    function company_sort($a, $b){
      global $company_list;
    
      $ac = count($company_list[$a]);
      $bc = count($company_list[$b]);

      if ($ac == $bc) return 0;
      else return ($ac < $bc) ? 1 : -1;
    }
  ?>

      <div id="companies">
        <div class="toolbar">
          <h1>Companies</h1>
          <a class="back" href="#home">Back</a>
        </div>
          <ul>
  <?
    uksort($company_list, "company_sort");
    foreach($company_list AS $hood=>$companies):
  ?>
              <!--<li class="sep"><div class="bgdiv"></div><p><?= $hood ?></p></li>-->
              <li><div class="bgdiv"></div><a href="#<?= preg_replace(array("/ /", "/\//"), "", $hood) ?>"><?= $hood ?> <small class="counter"><?= count($company_list[$hood]) ?></small></a></li>
  <?
    endforeach;
  ?>
          </ul>
      </div>
  <?
    foreach($company_list AS $hood=>$companies):
  ?>
      <div id="<?= preg_replace(array("/ /", "/\//"), "", $hood) ?>">
        <div class="toolbar">
          <h1><?= $hood ?></h1>
          <a class="back" href="#companies">Back</a>
        </div>
          <ul>
  <?
      foreach($companies AS $company):
  ?>
  	          <li><div class="bgdiv"></div><a href="#<?= $company["slug"] ?>"><?= $company["name"] ?>, <em><?= $company[address] ?></em></a></li>
  <?
      endforeach;
  ?>
          </ul>
      </div>
  <?
    endforeach;
  ?>
  </div>
		<script type="text/javascript"> 
		  var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
		  document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
		
		  try {
		    var pageTracker = _gat._getTracker("UA-103886-15");
		    pageTracker._trackPageview();
		  } catch(err) {}
		</script> 
	</body> 
</html>