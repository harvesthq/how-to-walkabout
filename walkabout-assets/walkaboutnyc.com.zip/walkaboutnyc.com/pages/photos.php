<style>h2 { font-weight:bold; font-size:1.15em;}</style>
<div class="content">
 <div class="con-bg"></div>
 <div class="content-container" id="photos">
  <h1 id="photos-head" class="headline">2010 Walkabout Memories</h1>

<!-- Start of Flickr Badge -->
<style type="text/css">
#flickr_badge_uber_wrapper {text-align:center; width:900px; float:left;}
#flickr_badge_wrapper {padding:10px 0 10px 0; float:left;}
.flickr_badge_image {margin:0px 15px 15px 0px; float:left;}
.flickr_badge_image img {width: 280px; height: 210px; border: 1px solid #dcdcdc !important;}
#flickr_badge_source {text-align:left; margin:0 10px 0 10px;}
#flickr_badge_icon {float:left; margin-right:5px;}
#flickr_www {display:block; padding:0 10px 0 10px !important; font: 11px Arial, Helvetica, Sans serif !important; color:#3993ff !important;}
#flickr_badge_uber_wrapper a:hover,
#flickr_badge_uber_wrapper a:link,
#flickr_badge_uber_wrapper a:active,
#flickr_badge_uber_wrapper a:visited {text-decoration:none !important; background:inherit !important;color:#3993ff;}
#flickr_badge_wrapper {}
#flickr_badge_source {padding:0 !important; font: 11px Arial, Helvetica, Sans serif !important; color:#666666 !important;}
</style>

<script type="text/javascript">
var yourURL = "flickr.com";
function outLinks() {
  var outLink;
  if (document.getElementsByTagName('a')) {
    for (var i = 0; (outLink = document.getElementsByTagName('a')[i]); i++) {
      if (outLink.href.indexOf(yourURL) > 0) {
        outLink.setAttribute('target', '_blank');
      }
    }
  }
}
window.onload = outLinks;
</script>

<div id="flickr_badge_uber_wrapper">
	<div id="flickr_badge_wrapper">
		<script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=9&display=latest&size=m&layout=x&source=user_set&user=49840400%40N02&set=72157624283744020&context=in%2Fset-72157624283744020%2F"></script>
	</div>
</div>
<!-- End of Flickr Badge -->

<div class="clear"></div>
<a href="http://www.flickr.com/groups/walkaboutnyc/pool/" target="new">See full album</a> 
</div>
</div>