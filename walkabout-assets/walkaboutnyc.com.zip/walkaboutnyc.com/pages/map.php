<div id="walkabout_mapspot">
  <div id="walkabout_directory">
    <ul>
      <?php if(preg_match('/iPad/i', $useragent)): ?>
      <li class="ipad-message">
        <b>iPad users:</b><br />
        Scroll companies with two fingers.
      </li>
      <? endif; ?>
<?
  foreach($companies AS $company):
    if(isset($company->address)):
?>
<li class="wa-com" id="<?= $company->slug ?>">
  <h2 class="<?= $company->slug ?>"><a href="<?= $company->url ?>"><?= $company->name ?></a><? if($company->slug=="pc-harvest"): ?><span id="hq_slash"> / <a href="http://walkaboutnyc.com">Walkabout HQ</a></span><? endif; ?></h2>
  <p class="wacom-address"><?= $company->address ?> &middot; <strong><?= $company->neighborhood ?></strong></p>
  <div>
    <p class="wacom-hours"><strong>Hours:</strong> <?= $company->hours; ?></p>
    <p class="wacom-description"><?= $company->description ?></p>
    <p class="wacom-details"><?= $company->details ?></p>
    <p class="wacom-url"><a href="<?= $company->url ?>"><?= $company->short_url(); ?></a></p></div>
  <input type="hidden" class="wacom-latlong" value="<?= $company->latlong ?>" />
</li>
<?
    endif;
  endforeach;
?>
    </ul>
  </div>
  <div id="walkabout_map"></div>
</div>
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>